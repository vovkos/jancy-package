//..............................................................................
//
//  This file is part of the Jancy toolkit.
//
//  Jancy is distributed under the MIT license.
//  For details see accompanying license.txt file,
//  the public copy of which is also available at:
//  http://tibbo.com/downloads/archive/jancy/license.txt
//
//..............................................................................

#pragma once

//..............................................................................

#define JNC_LLVM_VERSION_MAJOR 14
#define JNC_LLVM_VERSION_MINOR 0
#define JNC_LLVM_VERSION_PATCH 6

#define JNC_LLVM_VERSION ( \
	(JNC_LLVM_VERSION_MAJOR << 16) | \
	(JNC_LLVM_VERSION_MINOR << 8) | \
	JNC_LLVM_VERSION_PATCH \
)

#if (JNC_LLVM_VERSION < 0x030600)
#	define _JNC_LLVM_JIT_LEGACY 1
#elif (JNC_LLVM_VERSION_MAJOR >= 12)
#	define _JNC_LLVM_JIT_ORC    1
#endif

//..............................................................................
