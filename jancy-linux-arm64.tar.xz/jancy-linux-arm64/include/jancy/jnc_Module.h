//..............................................................................
//
//  This file is part of the Jancy toolkit.
//
//  Jancy is distributed under the MIT license.
//  For details see accompanying license.txt file,
//  the public copy of which is also available at:
//  http://tibbo.com/downloads/archive/jancy/license.txt
//
//..............................................................................

#pragma once

#define _JNC_MODULE_H

#include "jnc_Type.h"
#include "jnc_Namespace.h"
#include "jnc_CodeAssist.h"
#include "jnc_RuntimeStructs.h"

/**

\defgroup module-subsystem Module Components

\defgroup module Module
	\ingroup module-subsystem
	\import{jnc_Module.h}

\addtogroup module
@{

\struct jnc_Module
	\ingroup module-subsystem
	\verbatim

	Opaque structure used as a handle to Jancy module.

	Use functions from the `Module` group to access and manage the contents of this structure.

	\endverbatim

*/

//..............................................................................

enum jnc_ModuleCompileFlag {
	jnc_ModuleCompileFlag_DebugInfo                     = 0x00000001,
	jnc_ModuleCompileFlag_Assert                        = 0x00000002,
	jnc_ModuleCompileFlag_SimpleGcSafePoint             = 0x00000004,
	jnc_ModuleCompileFlag_GcSafePointInPrologue         = 0x00000010,
	jnc_ModuleCompileFlag_GcSafePointInInternalPrologue = 0x00000020,
	jnc_ModuleCompileFlag_ExternalExtensionBin          = 0x00000040,
	jnc_ModuleCompileFlag_DisableCodeGen                = 0x00000080,
	jnc_ModuleCompileFlag_Documentation                 = 0x00000200,
	jnc_ModuleCompileFlag_IgnoreOpaqueClassTypeInfo     = 0x00000400,
	jnc_ModuleCompileFlag_KeepTypedefShadow             = 0x00000800,
	jnc_ModuleCompileFlag_StdLibDoc                     = 0x00001000,
	jnc_ModuleCompileFlag_DisableDoxyComment1           = 0x00002000,
	jnc_ModuleCompileFlag_DisableDoxyComment2           = 0x00004000,
	jnc_ModuleCompileFlag_DisableDoxyComment3           = 0x00008000,
	jnc_ModuleCompileFlag_DisableDoxyComment4           = 0x00010000,

	jnc_ModuleCompileFlag_StdFlags                      = 0
};

typedef enum jnc_ModuleCompileFlag jnc_ModuleCompileFlag;

// . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

enum jnc_ModuleCompileState {
	jnc_ModuleCompileState_Idle,
	jnc_ModuleCompileState_Parsed,    // all files are parsed; global namespace is ready
	jnc_ModuleCompileState_Compiled,  // all required functions are compiled into LLVM IR
	jnc_ModuleCompileState_Jitted,    // machine code for all required functions is ready
};

typedef enum jnc_ModuleCompileState jnc_ModuleCompileState;

// . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

enum jnc_ModuleRequireFlag {
	jnc_ModuleRequireFlag_Essential = 0x01, // otherwise, optional (compile if found)
	jnc_ModuleRequireFlag_Traverse  = 0x02, // traverse to find exact location of the item
};

typedef enum jnc_ModuleRequireFlag jnc_ModuleRequireFlag;

// . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

enum jnc_ModuleCompileErrorKind {
	jnc_ModuleCompileErrorKind_ParseSyntax,   // -> llk::Parser::ErrorKind_Syntax
	jnc_ModuleCompileErrorKind_ParseSemantic, // -> llk::Parser::ErrorKind_Semantic
	jnc_ModuleCompileErrorKind_PostParse,     // post-parse stage
};

typedef enum jnc_ModuleCompileErrorKind jnc_ModuleCompileErrorKind;

// . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

// true  -> llk::Parser::RecoveryAction_Synchronize
// false -> llk::Parser::RecoveryAction_Fail

typedef
bool_t
jnc_ModuleCompileErrorHandlerFunc(
	void* context,
	jnc_ModuleCompileErrorKind errorKind
);

//..............................................................................

// get notified about attributed item declarations

typedef
void
jnc_AttributeObserverFunc(
	void* context,
	jnc_ModuleItem* item,
	jnc_AttributeBlock* attributeBlock
);

//..............................................................................

enum jnc_OptLevel {
	jnc_OptLevel_None       = 0,  // -O0
	jnc_OptLevel_Basic      = 1,  // -O1
	jnc_OptLevel_Standard   = 2,  // -O2
	jnc_OptLevel_Aggressive = 3,  // -O3
	jnc_OptLevel_Default    = jnc_OptLevel_Standard
};

typedef enum jnc_OptLevel nc_OptLevel;

//..............................................................................

enum jnc_JitKind {
	jnc_JitKind_Auto    = 0,
	jnc_JitKind_Legacy  = 1, // only on LLVM 3.5 or lower
	jnc_JitKind_McJit   = 2,
	jnc_JitKind_Orc     = 3, // only on LLVM 7.0 or higher
};

typedef enum jnc_JitKind jnc_JitKind;

//..............................................................................

// platform specific (authenticode on windows, codesign on osx, custom-made elf signer on linux)

struct jnc_CodeAuthenticatorConfig {
#if (_JNC_OS_WIN)
	const char* m_expectedSubjectName;
	const char* m_expectedIssuerName;
	const char* m_expectedSerialNumber;
	size_t m_expectedSerialNumberSize;
#elif (_JNC_OS_LINUX)
	const char* m_signatureSectionName;
	const char* m_publicKeyPem;
#elif (_JNC_OS_DARWIN)
	const char* m_expectedTeamId;
#endif

#ifdef __cplusplus
	jnc_CodeAuthenticatorConfig() {
		memset(this, 0, sizeof(jnc_CodeAuthenticatorConfig));
	}
#endif
};

typedef struct jnc_CodeAuthenticatorConfig jnc_CodeAuthenticatorConfig;

//..............................................................................

struct jnc_ModuleConfig {
	jnc_JitKind m_jitKind;
	uint_t m_jitOptLevel;
	uint_t m_compileFlags;
	size_t m_uniqueLinkIdBase;
};

typedef struct jnc_ModuleConfig jnc_ModuleConfig;

JNC_SELECT_ANY jnc_ModuleConfig jnc_g_defaultModuleConfig = {
	jnc_JitKind_Auto,
	jnc_OptLevel_Default,
	jnc_ModuleCompileFlag_StdFlags,
	0
};

//..............................................................................

JNC_EXTERN_C
jnc_Module*
jnc_Module_create();

JNC_EXTERN_C
void
jnc_Module_destroy(jnc_Module* module);

JNC_EXTERN_C
void
jnc_Module_clear(jnc_Module* module);

JNC_EXTERN_C
void
jnc_Module_unloadDynamicLibs(jnc_Module* module);

JNC_EXTERN_C
void
jnc_Module_initialize(
	jnc_Module* module,
	const char* name,
	const jnc_ModuleConfig* config
);

JNC_EXTERN_C
void
jnc_Module_updateCapabilities(jnc_Module* module);

JNC_EXTERN_C
void
jnc_Module_setDynamicExtensionAuthenticatorConfig(
	jnc_Module* module,
	const jnc_CodeAuthenticatorConfig* config
);

JNC_EXTERN_C
const char*
jnc_Module_getName(jnc_Module* module);

JNC_EXTERN_C
uint_t
jnc_Module_getCompileFlags(jnc_Module* module);

JNC_EXTERN_C
jnc_ModuleCompileState
jnc_Module_getCompileState(jnc_Module* module);

JNC_EXTERN_C
size_t
jnc_Module_getCompileErrorCountLimit(jnc_Module* module);

JNC_EXTERN_C
void
jnc_Module_setCompileErrorCountLimit(
	jnc_Module* module,
	size_t limit
);

JNC_EXTERN_C
size_t
jnc_Module_getCompileErrorCount(jnc_Module* module);

JNC_EXTERN_C
void
jnc_Module_setCompileErrorHandler(
	jnc_Module* module,
	jnc_ModuleCompileErrorHandlerFunc* handler,
	void* context
);

JNC_EXTERN_C
void
jnc_Module_setAttributeObserver(
	jnc_Module* module,
	jnc_AttributeObserverFunc* observer,
	void* context,
	uint_t itemKindMask
);

JNC_EXTERN_C
jnc_GlobalNamespace*
jnc_Module_getGlobalNamespace(jnc_Module* module);

JNC_EXTERN_C
jnc_GlobalNamespace*
jnc_Module_getStdNamespace(
	jnc_Module* module,
	jnc_StdNamespace stdNamespace
);

JNC_EXTERN_C
jnc_Type*
jnc_Module_getPrimitiveType(
	jnc_Module* module,
	jnc_TypeKind typeKind
);

JNC_EXTERN_C
jnc_Type*
jnc_Module_getStdType(
	jnc_Module* module,
	jnc_StdType stdType
);

JNC_EXTERN_C
handle_t
jnc_Module_getExtensionSourceFileIterator(jnc_Module* module);

JNC_EXTERN_C
const char*
jnc_Module_getNextExtensionSourceFile(
	jnc_Module* module,
	handle_t* iterator
);

JNC_EXTERN_C
jnc_FindModuleItemResult
jnc_Module_findExtensionLibItem(
	jnc_Module* module,
	const char* name,
	const jnc_Guid* libGuid,
	size_t itemCacheSlot
);

JNC_EXTERN_C
const char*
jnc_Module_getExtensionLibFilePath(
	jnc_Module* module,
	jnc_ExtensionLib* lib
);

JNC_EXTERN_C
bool_t
jnc_Module_mapVariable(
	jnc_Module* module,
	jnc_Variable* variable,
	void* p
);

JNC_EXTERN_C
bool_t
jnc_Module_mapFunction(
	jnc_Module* module,
	jnc_Function* function,
	void* p
);

JNC_EXTERN_C
void
jnc_Module_addSource(
	jnc_Module* module,
	jnc_ExtensionLib* lib,
	const char* fileName,
	const char* source,
	size_t length
);

JNC_EXTERN_C
handle_t
jnc_Module_getImportDirIterator(jnc_Module* module);

JNC_EXTERN_C
const char*
jnc_Module_getNextImportDir(
	jnc_Module* module,
	handle_t* iterator
);

JNC_EXTERN_C
void
jnc_Module_addImportDir(
	jnc_Module* module,
	const char* dir
);

JNC_EXTERN_C
bool_t
jnc_Module_addImport(
	jnc_Module* module,
	const char* fileName
);

JNC_EXTERN_C
void
jnc_Module_addSourceImport(
	jnc_Module* module,
	const char* fileName,
	const char* source,
	size_t length
);

JNC_EXTERN_C
void
jnc_Module_addIgnoredImport(
	jnc_Module* module,
	const char* fileName
);

JNC_EXTERN_C
void
jnc_Module_addOpaqueClassTypeInfo(
	jnc_Module* module,
	const char* qualifiedName,
	const jnc_OpaqueClassTypeInfo* info
);

JNC_EXTERN_C
void
jnc_Module_addStaticLib(
	jnc_Module* module,
	jnc_ExtensionLib* lib
);

JNC_EXTERN_C
void
jnc_Module_require(
	jnc_Module* module,
	jnc_ModuleItemKind itemKind,
	const char* name,
	uint_t flags
);

JNC_EXTERN_C
void
jnc_Module_requireType(
	jnc_Module* module,
	jnc_TypeKind typeKind,
	const char* name,
	uint_t flags
);

JNC_EXTERN_C
bool_t
jnc_Module_parse(
	jnc_Module* module,
	const char* fileName,
	const char* source,
	size_t length
);

JNC_EXTERN_C
bool_t
jnc_Module_parseFile(
	jnc_Module* module,
	const char* fileName
);

JNC_EXTERN_C
bool_t
jnc_Module_parseImports(jnc_Module* module);

JNC_EXTERN_C
bool_t
jnc_Module_compile(jnc_Module* module);

JNC_EXTERN_C
bool_t
jnc_Module_optimize(
	jnc_Module* module,
	uint_t level
);

JNC_EXTERN_C
bool_t
jnc_Module_ensureJitCreated(jnc_Module* module);

JNC_EXTERN_C
bool_t
jnc_Module_jit(jnc_Module* module);

JNC_EXTERN_C
bool_t
jnc_Module_generateDocumentation(
	jnc_Module* module,
	const char* outputDir
);

JNC_EXTERN_C
const char*
jnc_Module_getLlvmIrString_v(jnc_Module* module);

JNC_EXTERN_C
jnc_CodeAssist*
jnc_Module_generateCodeAssist(
	jnc_Module* module,
	const char* fileName,
	jnc_CodeAssistKind kind,
	size_t offset,
	const char* source,
	size_t length
);

JNC_EXTERN_C
void
jnc_Module_cancelCodeAssist(jnc_Module* module);

JNC_EXTERN_C
jnc_CodeAssist*
jnc_Module_getCodeAssist(jnc_Module* module);

// . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

#if (!defined _JNC_CORE && defined __cplusplus)
struct jnc_Module {
	static
	jnc_Module*
	create() {
		return jnc_Module_create();
	}

	void
	destroy() {
		jnc_Module_destroy(this);
	}

	void
	clear() {
		jnc_Module_clear(this);
	}

	void
	initialize(
		const char* name,
		const jnc_ModuleConfig* config = &jnc_g_defaultModuleConfig
	) {
		jnc_Module_initialize(this, name, config);
	}

	void
	unloadDynamicLibs() {
		jnc_Module_unloadDynamicLibs(this);
	}

	void
	updateCapabilities() {
		jnc_Module_updateCapabilities(this);
	}

	void
	setDynamicExtensionAuthenticatorConfig(const jnc_CodeAuthenticatorConfig* config) {
		jnc_Module_setDynamicExtensionAuthenticatorConfig(this, config);
	}

	const char*
	getName() {
		return jnc_Module_getName(this);
	}

	uint_t
	getCompileFlags() {
		return jnc_Module_getCompileFlags(this);
	}

	jnc_ModuleCompileState
	getCompileState() {
		return jnc_Module_getCompileState(this);
	}

	size_t
	getCompileErrorCountLimit() {
		return jnc_Module_getCompileErrorCountLimit(this);
	}

	void
	setCompileErrorCountLimit(size_t limit) {
		return jnc_Module_setCompileErrorCountLimit(this, limit);
	}

	size_t
	getCompileErrorCount() {
		return jnc_Module_getCompileErrorCount(this);
	}

	void
	setCompileErrorHandler(
		jnc_ModuleCompileErrorHandlerFunc* errorHandler,
		void* context
	) {
		jnc_Module_setCompileErrorHandler(this, errorHandler, context);
	}

	void
	setAttributeObserver(
		jnc_AttributeObserverFunc* observer,
		void* context,
		uint_t itemKindMask = (1 << jnc_ModuleItemKind_Function)
	) {
		jnc_Module_setAttributeObserver(this, observer, context, itemKindMask);
	}

	jnc_GlobalNamespace*
	getGlobalNamespace() {
		return jnc_Module_getGlobalNamespace(this);
	}

	jnc_GlobalNamespace*
	getStdNamespace(jnc_StdNamespace stdNamespace) {
		return jnc_Module_getStdNamespace(this, stdNamespace);
	}

	jnc_Type*
	getPrimitiveType(jnc_TypeKind typeKind) {
		return jnc_Module_getPrimitiveType(this, typeKind);
	}

	jnc_Type*
	getStdType(jnc_StdType stdType) {
		return jnc_Module_getStdType(this, stdType);
	}

	handle_t
	getExtensionSourceFileIterator() {
		return jnc_Module_getExtensionSourceFileIterator(this);
	}

	const char*
	getNextExtensionSourceFile(handle_t* iterator) {
		return jnc_Module_getNextExtensionSourceFile(this, iterator);
	}

	jnc_FindModuleItemResult
	findExtensionLibItem(
		const char* name,
		const jnc_Guid* libGuid,
		size_t itemCacheSlot
	) {
		return jnc_Module_findExtensionLibItem(this, name, libGuid, itemCacheSlot);
	}

	const char*
	getExtensionLibFilePath(jnc_ExtensionLib* lib) {
		return jnc_Module_getExtensionLibFilePath(this, lib);
	}

	bool
	mapVariable(
		jnc_Variable* variable,
		void* p
	) {
		return jnc_Module_mapVariable(this, variable, p) != 0;
	}

	bool
	mapFunction(
		jnc_Function* function,
		void* p
	) {
		return jnc_Module_mapFunction(this, function, p) != 0;
	}

	void
	addSource(
		jnc_ExtensionLib* lib,
		const char* fileName,
		const char* source,
		size_t length = -1
	) {
		jnc_Module_addSource(this, lib, fileName, source, length);
	}

	handle_t
	getImportDirIterator() {
		return jnc_Module_getImportDirIterator(this);
	}

	const char*
	getNextImportDir(handle_t* iterator) {
		return jnc_Module_getNextImportDir(this, iterator);
	}

	void
	addImportDir(const char* dir) {
		jnc_Module_addImportDir(this, dir);
	}

	bool
	addImport(const char* fileName) {
		return jnc_Module_addImport(this, fileName) != 0;
	}

	void
	addSourceImport(
		const char* fileName,
		const char* source,
		size_t length = -1
	) {
		jnc_Module_addSourceImport(this, fileName, source, length);
	}

	void
	addIgnoredImport(const char* fileName) {
		jnc_Module_addIgnoredImport(this, fileName);
	}

	void
	addOpaqueClassTypeInfo(
		const char* qualifiedName,
		const jnc_OpaqueClassTypeInfo* info
	) {
		jnc_Module_addOpaqueClassTypeInfo(this, qualifiedName, info);
	}

	void
	addStaticLib(jnc_ExtensionLib* lib) {
		jnc_Module_addStaticLib(this, lib);
	}

	void
	require(
		jnc_ModuleItemKind itemKind,
		const char* name,
		uint_t flags = jnc_ModuleRequireFlag_Essential
	) {
		jnc_Module_require(this, itemKind, name, flags);
	}

	void
	require(
		jnc_TypeKind typeKind,
		const char* name,
		uint_t flags = jnc_ModuleRequireFlag_Essential
	) {
		jnc_Module_requireType(this, typeKind, name, flags);
	}

	bool
	parse(
		const char* fileName,
		const char* source,
		size_t length = -1
	) {
		return jnc_Module_parse(this, fileName, source, length) != 0;
	}

	bool
	parseFile(const char* fileName) {
		return jnc_Module_parseFile(this, fileName) != 0;
	}

	bool
	parseImports() {
		return jnc_Module_parseImports(this) != 0;
	}

	bool
	compile() {
		return jnc_Module_compile(this) != 0;
	}

	bool
	optimize(uint_t level = jnc_OptLevel_Default) {
		return jnc_Module_optimize(this, level) != 0;
	}

	bool
	ensureJitCreated() {
		return jnc_Module_ensureJitCreated(this) != 0;
	}

	bool
	jit() {
		return jnc_Module_jit(this) != 0;
	}

	const char*
	getLlvmIrString_v() {
		return jnc_Module_getLlvmIrString_v(this);
	}

	bool
	generateDocumentation(const char* outputDir) {
		return jnc_Module_generateDocumentation(this, outputDir) != 0;
	}

	jnc_CodeAssist*
	generateCodeAssist(
		const char* fileName,
		jnc_CodeAssistKind kind,
		size_t offset,
		const char* source,
		size_t length = -1
	) {
		return jnc_Module_generateCodeAssist(this, fileName, kind, offset, source, length);
	}

	void
	cancelCodeAssist() {
		jnc_Module_cancelCodeAssist(this);
	}

	jnc_CodeAssist*
	getCodeAssist() {
		return jnc_Module_getCodeAssist(this);
	}
};
#endif // _JNC_CORE

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

#ifdef __cplusplus

namespace jnc {

//..............................................................................

typedef jnc_ModuleCompileState ModuleCompileState;

const ModuleCompileState
	ModuleCompileState_Idle     = jnc_ModuleCompileState_Idle,
	ModuleCompileState_Parsed   = jnc_ModuleCompileState_Parsed,
	ModuleCompileState_Compiled = jnc_ModuleCompileState_Compiled,
	ModuleCompileState_Jitted   = jnc_ModuleCompileState_Jitted;

typedef jnc_ModuleRequireFlag ModuleRequireFlag;

const ModuleRequireFlag
	ModuleRequireFlag_Essential = jnc_ModuleRequireFlag_Essential,
	ModuleRequireFlag_Traverse  = jnc_ModuleRequireFlag_Traverse;

typedef jnc_ModuleCompileFlag ModuleCompileFlag;

const ModuleCompileFlag
	ModuleCompileFlag_DebugInfo                     = jnc_ModuleCompileFlag_DebugInfo,
	ModuleCompileFlag_Assert                        = jnc_ModuleCompileFlag_Assert,
	ModuleCompileFlag_SimpleGcSafePoint             = jnc_ModuleCompileFlag_SimpleGcSafePoint,
	ModuleCompileFlag_GcSafePointInPrologue         = jnc_ModuleCompileFlag_GcSafePointInPrologue,
	ModuleCompileFlag_GcSafePointInInternalPrologue = jnc_ModuleCompileFlag_GcSafePointInInternalPrologue,
	ModuleCompileFlag_ExternalExtensionBin          = jnc_ModuleCompileFlag_ExternalExtensionBin,
	ModuleCompileFlag_DisableCodeGen                = jnc_ModuleCompileFlag_DisableCodeGen,
	ModuleCompileFlag_Documentation                 = jnc_ModuleCompileFlag_Documentation,
	ModuleCompileFlag_IgnoreOpaqueClassTypeInfo     = jnc_ModuleCompileFlag_IgnoreOpaqueClassTypeInfo,
	ModuleCompileFlag_KeepTypedefShadow             = jnc_ModuleCompileFlag_KeepTypedefShadow,
	ModuleCompileFlag_StdLibDoc                     = jnc_ModuleCompileFlag_StdLibDoc,
	ModuleCompileFlag_DisableDoxyComment1           = jnc_ModuleCompileFlag_DisableDoxyComment1,
	ModuleCompileFlag_DisableDoxyComment2           = jnc_ModuleCompileFlag_DisableDoxyComment2,
	ModuleCompileFlag_DisableDoxyComment3           = jnc_ModuleCompileFlag_DisableDoxyComment3,
	ModuleCompileFlag_DisableDoxyComment4           = jnc_ModuleCompileFlag_DisableDoxyComment4,
	ModuleCompileFlag_StdFlags                      = jnc_ModuleCompileFlag_StdFlags;

typedef jnc_ModuleCompileErrorHandlerFunc ModuleCompileErrorHandlerFunc;
typedef jnc_ModuleCompileErrorKind ModuleCompileErrorKind;

const ModuleCompileErrorKind
	ModuleCompileErrorKind_ParseSyntax   = jnc_ModuleCompileErrorKind_ParseSyntax,
	ModuleCompileErrorKind_ParseSemantic = jnc_ModuleCompileErrorKind_ParseSemantic,
	ModuleCompileErrorKind_PostParse     = jnc_ModuleCompileErrorKind_PostParse;

typedef jnc_AttributeObserverFunc AttributeObserverFunc;

typedef jnc_OptLevel OptLevel;

const OptLevel
	OptLevel_None       = jnc_OptLevel_None,
	OptLevel_Basic      = jnc_OptLevel_Basic,
	OptLevel_Standard   = jnc_OptLevel_Standard,
	OptLevel_Aggressive = jnc_OptLevel_Aggressive,
	OptLevel_Default    = jnc_OptLevel_Default;

typedef jnc_JitKind JitKind;

const JitKind
	JitKind_Auto   = jnc_JitKind_Auto,
	JitKind_Legacy = jnc_JitKind_Legacy,
	JitKind_McJit  = jnc_JitKind_McJit,
	JitKind_Orc    = jnc_JitKind_Orc;

typedef jnc_CodeAuthenticatorConfig CodeAuthenticatorConfig;
typedef jnc_ModuleConfig ModuleConfig;

const ModuleConfig g_defaultModuleConfig = jnc_g_defaultModuleConfig;

//..............................................................................

class AutoModule {
protected:
	Module* m_module;

public:
	AutoModule() {
		m_module = jnc_Module_create();
	}

	~AutoModule() {
		release();
	}

	operator Module* () const {
		return m_module;
	}

	Module*
	operator -> () const {
		JNC_ASSERT(m_module);
		return m_module;
	}

	Module*
	p() const {
		return m_module;
	}

	void
	release();
};

// . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

inline
void
AutoModule::release() {
	if (!m_module)
		return;

	jnc_Module_destroy(m_module);
	m_module = NULL;
}

//..............................................................................

} // namespace jnc

#endif // __cplusplus

/// @}
