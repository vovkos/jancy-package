#...............................................................................
#
#  This file is part of the Jancy toolkit.
#
#  Jancy is distributed under the MIT license.
#  For details see accompanying license.txt file,
#  the public copy of which is also available at:
#  http://tibbo.com/downloads/archive/jancy/license.txt
#
#...............................................................................

get_filename_component(JANCY_INSTALL_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

set(JANCY_BIN_DIR    "${JANCY_INSTALL_PREFIX}/bin")
set(JANCY_DLL_DIR    "${JANCY_INSTALL_PREFIX}/lib")
set(JANCY_JNCX_DIR   "${JANCY_INSTALL_PREFIX}/share/jancy/extensions")
set(JANCY_INC_DIR    "${JANCY_INSTALL_PREFIX}/include/jancy")
set(JANCY_LIB_DIR    "${JANCY_INSTALL_PREFIX}/lib")
set(JANCY_CMAKE_DIR  "${JANCY_INSTALL_PREFIX}/lib/cmake/jancy")
set(JANCY_SPHINX_DIR "${JANCY_INSTALL_PREFIX}/share/jancy/sphinx")
set(JANCY_TOOL_DIR   "${JANCY_INSTALL_PREFIX}/share/jancy/tools")

set(JANCY_EXE        "${JANCY_BIN_DIR}/jancy")
set(JNC2CPP_PL       "${JANCY_TOOL_DIR}/jnc2cpp/jnc2cpp.pl")
set(FILE2LITERAL_PL  "${JANCY_TOOL_DIR}/file2literal/file2literal.pl")

if(WIN32)
	set(JANCY_DLL_NAME      jancy-2.0)
	set(JANCY_EDIT_DLL_NAME jancy-edit-2.0)
else()
	set(JANCY_DLL_NAME      jancy)
	set(JANCY_EDIT_DLL_NAME jancy-edit)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/jancy_version.cmake")

set(JANCY_LLVM_VERSION_MAJOR 14)
set(JANCY_LLVM_VERSION_MINOR 0)
set(JANCY_LLVM_VERSION_PATCH 6)

set(JANCY_LLVM_JIT_ORC       )
set(JANCY_LLVM_JIT_LEGACY    )

#...............................................................................
